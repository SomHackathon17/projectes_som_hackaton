﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Drag : MonoBehaviour {
	float x;
	float y;
	public GameObject prefab;

	
	// Update is called once per frame
	void Update () {
		 x = Input.mousePosition.x;
		 y = Input.mousePosition.y;
		if(Input.GetMouseButtonDown(0))
		{
			Instantiate(prefab, new Vector3(x, 0.5f, y), Quaternion.identity);
			Debug.Log("Posicion de x:" + x);
			Debug.Log("Posicion de y:" + y);
		}
	}

}