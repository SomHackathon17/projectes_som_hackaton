﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class ViewModel : MonoBehaviour 
{

    public void Button_Click()
    {
        Debug.Log("Hello, World!");
    }

}
