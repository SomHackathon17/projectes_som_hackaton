
$(document).ready(function() {

    var heightHeader = parseInt($(".dvSuperior").css("height"));
    heightHeader += parseInt($(".dvSuperior").css("padding-top"));
    heightHeader += parseInt($(".dvSuperior").css("padding-bottom"));
    $(".dvCapaImagen").css("margin-top", heightHeader + "px");

    var heightFormulario = "calc(" + $(".dvCapaImagen").css("height");
    heightFormulario += " - " + $(".dvInferior").css("margin-top") + " - 6px)";
    $(".dvInferior").css("height", heightFormulario);
    
});
