# Dility

Making mobility data easy for everyone.

#Installation
##To install Dility

```
git clone ...
pip install flask
pip install request
cd dility
python __main__.py
````

#Contribute

Welcome ye Hacker! All ideas are welcome, open/close issues, fork the repo and share your code with a Pull Request.

You can clone this project to your machine:

git clone https://github.com/ericalcaide/dmobility/
