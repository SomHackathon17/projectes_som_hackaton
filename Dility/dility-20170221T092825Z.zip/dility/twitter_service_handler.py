# Fem un handler per servei
import requests

def getData(user):
	if user=="renfe":
		return getRenfeData()

def getRenfeData():
	raw = requests.get("http://loklak.org/api/search.json?q=renfe+INFO").json()
	return raw