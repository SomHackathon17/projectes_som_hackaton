#-*- coding: utf-8 -*-
import sys,json,requests

def numbers_to_strings(argument):
    switcher = {
        1: "Accident",
        2: "Congestion",
        3: "Disabled vehicle",
        4: "Mass transit",
        5: "Miscellaneous",
        6: "Other news",
        7: "Planed event",
        8: "Road hazard",
        9: "Construction",
        10: "Alert",
        11: "Weather",
    }
    return switcher.get(argument,'nothing')

def getData():
	response = requests.get('http://dev.virtualearth.net/REST/v1/Traffic/Incidents/41.300779,2.019621,42.057638,2.449870?key=qY3QwHFgDScoXtQsi8EM~J-ziwr8HHV15IaP6RSEDJw~AsL1DjNMjh31bjdrp_sw4tVCKNUFfYCCfv_RfNHnolvTUzLvK3Bvf7x0Jie810NY').json()
	return response

def createMsnList(prejson):
	temp=list()

	resource_sets = prejson['resourceSets']

	for i in range(len(resource_sets)):
		resources = resource_sets[i]['resources']
		for j in range(len(resources)):
			incidence_types = numbers_to_strings(resources[j]['type'])
			coordinates = resources[j]['point']['coordinates']

			dict1 = {'lat':coordinates[0],'lon':coordinates[1],'type':incidence_types,'source':'Microsoft API'}
			temp.append(dict1)

	return temp

def getIncidents():
    lista = list()
    prejson = getData()
    lista = createMsnList(prejson)
    return lista

