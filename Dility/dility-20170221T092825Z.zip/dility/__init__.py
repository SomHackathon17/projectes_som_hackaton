from flask import Flask
from flask import render_template
from flask import request
from flask import jsonify
import twitter_service_handler
import microsoft_service_handler
import requests

app = Flask(__name__)

placeholders = {'Sustainability':'/api/twitter/renfe/','Traffic':'/api/incidents/cooked/','IoT':''}

@app.route('/')
def web():
	return render_template('index.html')

@app.route('/api/<platform>/<query>/')
def api(platform, query):
	raw = {'Response':'None'}
	if platform=="twitter":
		raw = twitter_service_handler.getData(query)
	return jsonify(raw)

@app.route('/api/dummy/')
def dummy_api():
	raw = requests.get("http://loklak.org/api/search.json?&q=dummy").json()
	return jsonify(raw)

@app.route('/api/incidents/<source>/')
def incidents(source):
	raw = {'Response':'None'}
	if source=="cooked":
		raw = microsoft_service_handler.getIncidents()
	if source=="origin":
		raw = microsoft_service_handler.getData()
	return jsonify(raw)

@app.route('/api/mapsdata/<platform>/')
def mapsdata(platform):
	pass


@app.route('/graphs/')
def graphs():
	return render_template('graphs.html')

@app.route('/info/')
def info():
	return render_template('info.html')

@app.route('/contact/')
def contact():
	return render_template('contact.html')

@app.route('/datasets/<dataset>/')
def dataset(dataset):
	placeholder=placeholders[dataset]
	return render_template('dataset.html', dataset=dataset, placeholder=placeholder)

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')
