package cat.tecnocampus.domain.misc;

/**
 * Created by carlo on 12/02/2017.
 */
public class Duration {
    private int value;
    private String va;
    private String unity;

    public Duration(){}
    public Duration(String value){
        this.va = value;
        this.unity = "s";
    }
    public Duration(int value, String unity){
        this.value = value;
        this.unity = unity;
    }

    @Override
    public String toString() {
        if (va!=null)
        return "Duration{" +
                "\nvalue=" + value +
                ",\n unity='" + unity + '\'' +
                '}';
        else
            return "Duration{" +
                    "\nvalue=" + va +
                    ",\n unity='" + unity + '\'' +
                    '}';
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }

    public String getUnity() {
        return unity;
    }

    public void setUnity(String unity) {
        this.unity = unity;
    }
}
