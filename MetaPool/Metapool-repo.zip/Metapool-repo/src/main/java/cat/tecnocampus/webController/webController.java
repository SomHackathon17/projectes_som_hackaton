package cat.tecnocampus.webController;

import cat.tecnocampus.domain.trips.Trip;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

/**
 * Created by jordiadan on 11/2/17.
 */
@Controller
public class webController {
    public static Model model;
    public webController(){

    }

    @GetMapping("/index")
    public String index(){
        return "index";
    }

    @GetMapping("/result")
    public String result(@ModelAttribute("tripList") LinkedList<Trip> lista){
        System.out.println("Redireccionado!");
        //System.out.println(lista.toString());
        return "index";
    }
}
