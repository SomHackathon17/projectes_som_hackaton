package cat.tecnocampus.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.LinkedList;
import java.util.List;
import cat.tecnocampus.domain.trips.TripBlaBla;

/**
 * Created by Raul ~ on 11/02/2017.
 */



@JsonIgnoreProperties(ignoreUnknown = true)
public class topMeme {

    private List<TripBlaBla> trips;
    public topMeme(){
        trips = new LinkedList<TripBlaBla>();
    }

    public List<TripBlaBla> getTrips() {
        return trips;
    }

    public void setTrips(List<TripBlaBla> trips) {
        this.trips = trips;
    }

    public topMeme(List<TripBlaBla> trips) {
        this.trips = trips;
    }

    @Override
    public String toString() {
        return "BlablaCar = {" +
                 trips +
                '}';
    }

    public topMeme addDankMemes(topMeme topmeme){
        this.trips.addAll(topmeme.getTrips());
        return this;
    }
}
