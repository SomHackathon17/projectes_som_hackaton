package cat.tecnocampus.domain.location;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by carlo on 11/02/2017.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class Location {
    private String city_name;
    private String address;
    private float latitude;
    private float longitude;
    private String country_code;

    public Location(){}
    public Location(String city_name, String address, float latitude, float longitude, String country_code) {
        this.city_name = city_name;
        this.address = address;
        this.latitude = latitude;
        this.longitude = longitude;
        this.country_code = country_code;
    }

    public String toString() {
        return "Name: " + this.city_name + "\n" +
                "Address: " + this.address + "\n" +
                "Longitude: " + this.longitude + "\n" +
                "Latitude: " + this.latitude + "\n" +
                "Country Code: " + this.country_code.toString();
    }

    public void setCity_name(String city_name) {
        this.city_name = city_name;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setLatitude(float latitude) {
        this.latitude = latitude;
    }

    public void setLongitude(float longitude) {
        this.longitude = longitude;
    }

    public void setCountry_code(String country_code) {
        this.country_code = country_code;
    }

    public String getCity_name() {

        return city_name;
    }

    public String getAddress() {
        return address;
    }

    public float getLatitude() {
        return latitude;
    }

    public float getLongitude() {
        return longitude;
    }

    public String getCountry_code() {
        return country_code;
    }
}
