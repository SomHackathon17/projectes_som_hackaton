package cat.tecnocampus.domain.trips;

import cat.tecnocampus.domain.money.Price;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Date;

/**
 * Created by 0 k x on 11/02/2017.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class Ride extends Trip{

    @JsonProperty("departure_date_time")
    private String departure_date_time;
    @JsonProperty("price_amount")
    private String price_amount;
    @JsonProperty("price_currency")
    private String price_currency;
    @JsonProperty("duration")
    private String duration;
    @JsonProperty("distance")
    private int distance;

    @JsonCreator
    public Ride(@JsonProperty("departure_date_time") String departure_date_time, @JsonProperty("price_amount") String price_amount,
                @JsonProperty("price_currency") String price_currency, @JsonProperty("duration") String duration,
                @JsonProperty("distance") int distance) {
        this.departure_date_time = departure_date_time;
        this.price_amount = price_amount;
        this.price_currency = price_currency;
        this.duration = duration;
        this.distance = distance;
        super.superPrice = new Price(Float.parseFloat(price_amount), price_currency, "€", Float.parseFloat(price_amount)+"€", "BLACK");
        super.superDate = new Date();

    }

    @JsonCreator
    public Ride() {
    }

    public String getDeparture_date_time() {
        return departure_date_time;
    }

    public void setDeparture_date_time(String departure_date_time) {
        this.departure_date_time = departure_date_time;
    }

    public String getPrice_amount() {
        return price_amount;
    }

    public void setPrice_amount(String price_amount) {
        this.price_amount = price_amount;
    }

    public String getPrice_currency() {
        return price_currency;
    }

    public void setPrice_currency(String price_currency) {
        this.price_currency = price_currency;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }

    public int getDistance() {
        return distance;
    }

    public void setDistance(int distance) {
        this.distance = distance;
    }

    @Override
    public String toString() {
        return "RideGoMore{" +
                "\n departure_date_time='" + departure_date_time + '\'' +
                ",\n price_amount='" + price_amount + '\'' +
                ",\n price_currency='" + price_currency + '\'' +
                ",\n duration='" + duration + '\'' +
                ",\n distance=" + distance +
                '}';
    }
}
