package cat.tecnocampus.domain.trips;

import cat.tecnocampus.domain.money.Price;

import java.util.Comparator;
import java.util.Date;

/**
 * Created by carlo on 12/02/2017.
 */
public class Trip {
    protected Price superPrice;
    protected Date superDate;
    public Price getSuperPrice(){return this.superPrice;}
    public Date getSuperDate(){return this.superDate;}

    public int compareToTime(Object o){
        return this.superDate.compareTo(((Trip)o).superDate);
    }

    public static class ComparePrice implements Comparator<Trip> {
        @Override
        public int compare(Trip o1, Trip o2) {
            if (o1 == null || o1.getSuperPrice() == null) return -1;
            else if (o2 == null || o2.getSuperPrice() == null) return +1;
            return (int) (o1.getSuperPrice().getValue()-o2.getSuperPrice().getValue());
        }
    }

    public static class CompareDate implements Comparator<Trip>{
        @Override
        public int compare(Trip o1, Trip o2){
            if (o1 == null) return -1;
            else if (o2 == null) return +1;
            return o1.getSuperDate().compareTo(o2.getSuperDate());
        }
    }

}


