package cat.tecnocampus.domain.trips;

import cat.tecnocampus.domain.location.Location;
import cat.tecnocampus.domain.misc.Distance;
import cat.tecnocampus.domain.misc.Duration;
import cat.tecnocampus.domain.money.Price;

import java.util.Date;
import java.util.spi.CalendarNameProvider;

/**
 * Created by carlo on 12/02/2017.
 */
public class TripBlaBla extends Trip{
    private Location departure_place;
    private Location arrival_place;
    private Price price;
    private Duration duration;
    private Distance distance;
    private String departure_date;

    public TripBlaBla(){}
    public TripBlaBla(Location departure_place, Location arrival_place, Price price, Duration duration, Distance distance, String departure_date) {
        this.departure_place = departure_place;
        this.arrival_place = arrival_place;
        this.price = price;
        this.duration = duration;
        this.distance = distance;
        this.departure_date = departure_date;
        super.superDate = new Date();
        super.superDate.setTime(0L);
        super.superPrice = price;
    }

    @Override
    public String toString() {
        return "\nTripBlaBla{" +
                " departure_place=" + departure_place +
                ",\n arrival_place=" + arrival_place +
                ",\n price=" + price +
                ",\n duration=" + duration +
                ",\n distance=" + distance +
                ",\n departure_date='" + departure_date + '\'' +
                '}';
    }

    public Location getDeparture_place() {
        return departure_place;
    }

    public void setDeparture_place(Location departure_place) {
        this.departure_place = departure_place;
    }

    public Location getArrival_place() {
        return arrival_place;
    }

    public void setArrival_place(Location arrival_place) {
        this.arrival_place = arrival_place;
    }

    public Price getPrice() {
        return price;
    }

    public void setPrice(Price price) {
        this.price = price;
    }

    public Duration getDuration() {
        return duration;
    }

    public void setDuration(Duration duration) {
        this.duration = duration;
    }

    public Distance getDistance() {
        return distance;
    }

    public void setDistance(Distance distance) {
        this.distance = distance;
    }

    public String getDeparture_date() {
        return departure_date;
    }

    public void setDeparture_date(String departure_date) {
        this.departure_date = departure_date;
    }
}
