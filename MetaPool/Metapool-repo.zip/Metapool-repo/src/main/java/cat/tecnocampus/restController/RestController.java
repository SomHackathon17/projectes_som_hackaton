package cat.tecnocampus.restController;

import cat.tecnocampus.domain.topMeme;
import cat.tecnocampus.domain.topMeme2;
import cat.tecnocampus.domain.trips.Trip;
import cat.tecnocampus.webController.webController;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;

/**
 * Created by Raul ~ on 11/02/2017.
 */
@Controller
public class RestController {

    private String lyftAPI = "";
    private webController webController;

    public RestController(webController webController) {
        this.webController = webController;
        this.lyftAPI = lyftAPI;
    }

    @RequestMapping(method = RequestMethod.POST, value = "/getRoutes")
    private ModelAndView getRoute(@RequestBody LinkedList<String> urls) {
        RestTemplate restTemplate = new RestTemplate();
        topMeme trips = new topMeme();
        topMeme2 rides = new topMeme2();
        Comparator comp = new Trip.ComparePrice();
        for(String str : urls){
            String json = str.replaceAll("amp;","");
            String filter = json.substring(0,2);
            String rest = json.substring(2);
            if (filter.equals("BL"))
                trips.addDankMemes(restTemplate.getForObject(rest, topMeme.class));
            else if (filter.equals("GO"))
                rides.addDankMemes(restTemplate.getForObject(rest, topMeme2.class));
            else if (filter.equals("FP"))
                comp = new Trip.ComparePrice();
            else if (filter.equals("FD"))
                comp = new Trip.CompareDate();

        }
        LinkedList<Trip> lista = new LinkedList<Trip>();
        lista.addAll(trips.getTrips());
        lista.addAll(rides.getData());
        Collections.sort(lista, comp);
        System.out.println(trips.toString());
        System.out.println(rides.toString());
        return new ModelAndView("redirect:/result");
    }
}
