package cat.tecnocampus.domain.money;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
// The safest declaration: The money is important b0ss
@JsonIgnoreProperties(ignoreUnknown = true)
public class Price {
    @JsonProperty("value")
    private float value;
    @JsonProperty("currency")
    private String currency;
    @JsonProperty("symbol")
    private String symbol;
    @JsonProperty("string_value")
    private String string_value;
    @JsonProperty("price_color")
    private String price_color;

    @JsonCreator
    public Price(@JsonProperty("value")
                         float value, @JsonProperty("currency")
                         String currency, @JsonProperty("symbol")
                         String symbol, @JsonProperty("string_value")
                         String string_value, @JsonProperty("price_color")
                         String price_color) {
        this.value = value;
        this.currency = currency;
        this.symbol = symbol;
        this.string_value = string_value;
        this.price_color = price_color;
    }

    public float getValue() {
        return value;
    }

    public void setValue(float value) {
        this.value = value;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getSymbol() {
        return symbol;
    }

    public void setSymbol(String symbol) {
        this.symbol = symbol;
    }

    public String getString_value() {
        return string_value;
    }

    public void setString_value(String string_value) {
        this.string_value = string_value;
    }

    public String getPrice_color() {
        return price_color;
    }

    public void setPrice_color(String price_color) {
        this.price_color = price_color;
    }

    public String toString() {
        return this.string_value;

    }
}