package cat.tecnocampus.domain.misc;

/**
 * Created by carlo on 12/02/2017.
 */
public class Distance {
    private int value;
    private String unity;

    public Distance(){}
    public Distance(int value){
        this.value = value;
        this.unity = "m";
    }
    public Distance(int value, String unity){
        this.value = value;
        this.unity = unity;
    }

    @Override
    public String toString() {
        return "Distance{" +
                "\nvalue=" + value +
                ",\n unity='" + unity + '\'' +
                '}';
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }

    public String getUnity() {
        return unity;
    }

    public void setUnity(String unity) {
        this.unity = unity;
    }
}
