package cat.tecnocampus.domain;

import cat.tecnocampus.domain.trips.Ride;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.LinkedList;
import java.util.List;

/**
 * Created by 0 k x on 11/02/2017.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class topMeme2 {

    @JsonProperty("data")
    private List<Ride> data;

    @JsonCreator
    public topMeme2(@JsonProperty("data") List<Ride> data) {
        this.data = data;
    }

    @JsonCreator
    public topMeme2() {
        this.data = new LinkedList<Ride>();
    }

    public List<Ride> getData() {
        return data;
    }

    public void setData(List<Ride> data) {
        this.data = data;
    }

    public topMeme2 addDankMemes(topMeme2 topmeme){
        this.data.addAll(topmeme.getData());
        return this;
    }

    @Override
    public String toString() {
        return "GoMore = {" +
                data +
                '}';
    }
}
