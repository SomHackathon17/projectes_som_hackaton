function Comp(){
    var user = parseInt(document.getElementById("punts").value);
    var tabla = new Array(10000, 90000, 7000, 6000, 5000, 4000, 3000, 2000, 1000);
    var i;
    for(i=0; tabla[i] < user && i!=8; i++){
    }
    if(tabla[i] < user && i == 0){
      document.write.getElementById("rank") = 11;
    }
    else if(i == 8){
      document.write.getElementById("rank") = 1;
    }
    else{
      document.write.getElementById("rank") = i;
    }
  }
  function openCity(evt, cityName) {
  	var i, x, tablinks;
  	x = document.getElementsByClassName("city");
  	for (i = 0; i < x.length; i++) {
  		x[i].style.display = "none";
  	}
  	tablinks = document.getElementsByClassName("tablink");
  	for (i = 0; i < x.length; i++) {
  		tablinks[i].className = tablinks[i].className.replace(" ", "");
  	}
  	document.getElementById(cityName).style.display = "block";
  	evt.currentTarget.className += " ";
  	}
